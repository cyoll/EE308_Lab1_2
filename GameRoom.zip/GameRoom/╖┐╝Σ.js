// 要操作的元素
const invitebox=document.querySelector('.invitebox');
const invite=document.querySelector('.invite');
const player2=document.querySelector('.player2');
const player3=document.querySelector('.player3');
const player4=document.querySelector('.player4');
const check=document.querySelector('.check');
// 为按钮绑定点击事件
var user2 = console;
player2.addEventListener('click',function(){
    invitebox.classList.toggle('active1');
})
player3.addEventListener('click',function(){
    invitebox.classList.toggle('active1');
})
player4.addEventListener('click',function(){
    invitebox.classList.toggle('active1');
})
// check.addEventListener('click',function(){
//     invitebox.classList.toggle('active');
// })
//1
var temp=0;
function inv2(){
    temp=2;
}
function add2(){
    var id2=document.getElementById('id').value;
document.getElementById('user2').innerHTML=id2;
}

function inv3(){
    temp=3;
}
function add3(){
    var id3=document.getElementById('id').value;
document.getElementById('user3').innerHTML=id3;
}
function inv4(){
    temp=4;
}
function add4(){
    var id4=document.getElementById('id').value;
document.getElementById('user4').innerHTML=id4;
}
function yes2(){
    if(temp===2){
        add2();
        document.getElementById('id').value='';
         invitebox.classList.toggle('active1');
          invitebox.classList.toggle('active2');
}
    if(temp===3){
        add3();
        document.getElementById('id').value='';
        invitebox.classList.toggle('active1');
        invitebox.classList.toggle('active3');
    }
    if(temp===4){
        add4();
        document.getElementById('id').value='';
        invitebox.classList.toggle('active1');
        invitebox.classList.toggle('active4');
    }
}
function load(id){
    var toast = document.getElementById("tosspot")
    var omit =document.getElementById("canal")
    if(id==="add"){
        toast.style.visibility="visible"
    }
    else{
        omit.style.visibility="visible"
    }
}

