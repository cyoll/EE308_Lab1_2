function tohome(){
    window.location.href="主页.html";
}