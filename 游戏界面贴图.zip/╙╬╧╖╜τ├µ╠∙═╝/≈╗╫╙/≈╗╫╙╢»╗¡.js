let arr=["点数1.svg","点数2.svg","点数3.svg","点数4.svg","点数5.svg","点数6.svg"];
function getrandom(min,max){//取随机数
    return Math.floor(Math.random()*(max-min+1))+min
}

let btn=document.querySelector('#btn')
let pic1=document.querySelector('#img1')
let pic2=document.querySelector('#img2')
let pic3=document.querySelector('#img3')
let pic4=document.querySelector('#img4')
let pic5=document.querySelector('#img5')
let pic6=document.querySelector('#img6')
let tit=document.querySelector('div')
var a1,a2,a3,a4,a5,a6;
function clock(){
    let random1=getrandom(0,arr.length-1)
    a1==random1
    pic1.src=arr[random1]
    let random2=getrandom(0,arr.length-1)
    pic2.src=arr[random2]
    let random3=getrandom(0,arr.length-1)
    pic3.src=arr[random3]
    let random4=getrandom(0,arr.length-1)
    pic4.src=arr[random4]
    let random5=getrandom(0,arr.length-1)
    pic5.src=arr[random5]
    let random6=getrandom(0,arr.length-1)
    pic6.src=arr[random6]    
}

let flag=true;
let time;

function start(){
    
    if(flag==false){
        document.getElementById("img11").style.animation="d10 1s 5 linear";
        document.getElementById("img22").style.animation="d20 1s 5 linear";
        document.getElementById("img33").style.animation="d30 1s 5 linear";
        document.getElementById("img44").style.animation="d40 1s 5 linear";
        document.getElementById("img55").style.animation="d50 1s 5 linear";
        document.getElementById("img66").style.animation="d60 1s 5 linear";
        let result=[];
        result[0]=a1;
        result[1]=a2;
        result[2]=a3;
        result[3]=a4;
        result[4]=a5;
        result[5]=a6;
        time=window.clearInterval(time);
        btn.value='摇';
        flag=true;
    }
    else{
        document.getElementById("img11").style.animation="d11 1s 5 linear";
        document.getElementById("img22").style.animation="d22 1s 5 linear";
        document.getElementById("img33").style.animation="d33 1s 5 linear";
        document.getElementById("img44").style.animation="d44 1s 5 linear";
        document.getElementById("img55").style.animation="d55 1s 5 linear";
        document.getElementById("img66").style.animation="d66 1s 5 linear";

        time=self.setInterval("clock()",30);

        btn.value='停';
        flag=false;
    }
}
